# Ovation — Logo v4 assets

Source of truth: `Logo v4.html` from the Claude Design handoff bundle.
Figma file (partially built): https://www.figma.com/design/Bt0OcfyOzRpPBqqg22zuUx

## Already built in Figma

- `Logo / Mark` component (exact 8-petal vector, champagne `#B89765` petals, ink `#1F1B17` dot)
- 01 · Icon only
- 02 · Horizontal lockup (mark 120 + wordmark 92px)
- 03 · Stacked lockup (mark 96 + wordmark 56px + tagline)
- 04 · App icon system — first 3 of 6 colorways (Ivory, Ink & champagne, Champagne)

## Remaining sections (drag SVGs from this folder, or duplicate existing nodes)

- 04 · App icons 4–6: `app-icon/04-blush.svg`, `05-sage.svg`, `06-paper-gold.svg`
  (220×220, corner radius 52, corner smoothing 0.6, shadow 0/24/80 ink 10%)
- 05 · Mono: `icon/mark-mono-black.svg` on white, `mark-mono-white.svg` on black,
  next to wordmark at 48px / letter-spacing 2.5
- 06 · Scale row: mark instances at 16 / 24 / 40 / 64 / 96 / 128 (16 + 24 all-ink)
- 07 · Palette swatches

## Wordmark spec

- Font: Cormorant Garamond Regular, uppercase
- Letter-spacing ≈ 4.5% of font size (92px → 4, 56px → 2.5, 48px → 2.5, 132px → 6)
- Tagline: IBM Plex Mono Medium 11px, letter-spacing 5, uppercase, `#8E7045`,
  text "— memories, held —"
- Labels: IBM Plex Mono Medium 10–11px, letter-spacing 2, uppercase, ink 40% (light bg)
  or ivory 50% (dark bg)

## Palette

| Name           | Hex       | Role      |
| -------------- | --------- | --------- |
| Warm Ivory     | `#F6EFE2` | base      |
| Champagne Gold | `#B89765` | accent    |
| Soft Blush     | `#E5C5BD` | highlight |
| Deep Charcoal  | `#1F1B17` | ink       |
| Muted Sage     | `#A0B098` | optional  |

Supporting: Ivory Deep `#ECE2CE`, Paper `#FBF6EA`, Gold Deep `#8E7045`, Gold Soft `#D4BC95`.
